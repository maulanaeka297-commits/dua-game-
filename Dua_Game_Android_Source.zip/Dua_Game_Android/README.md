# Dua Game Android

Satu aplikasi berisi:
1. **Meja Catur** — mode Vs AI sederhana atau 2 pemain satu layar.
2. **Speedy Dash** — game lari 2D, lompat, boost, rintangan, koin, skor, dan rekor.

## Cara membuka project
1. Ekstrak ZIP ini.
2. Buka folder `Dua_Game_Android` di Android Studio.
3. Tunggu Gradle Sync selesai.
4. Pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. APK debug ada di `app/build/outputs/apk/debug/app-debug.apk`.

## Build APK lewat GitHub Actions
1. Buat repository GitHub baru.
2. Upload semua isi folder ini ke repository (termasuk `.github`).
3. Buka tab **Actions**.
4. Jalankan workflow **Build Android APK** (atau tunggu build otomatis setelah push).
5. Setelah selesai, buka hasil workflow dan unduh artifact `Dua-Game-debug`.
6. Ekstrak artifact, lalu install `app-debug.apk` di Android.

## Edit game
- Tampilan dan game ada di `app/src/main/assets/index.html`.
- Kode pembungkus Android ada di `app/src/main/java/com/eka/duagame/MainActivity.java`.
- Nama aplikasi dan versi ada di `app/build.gradle`.

## Catatan fitur catur
Versi awal ini mendukung gerakan dasar bidak, giliran, makan bidak, promosi pion, Undo, mode 2 pemain, dan AI sederhana. Ini belum menerapkan seluruh aturan resmi catur seperti rokade, en passant, dan deteksi skak/skakmat. AI memilih langkah sederhana, bukan mesin catur kuat.

## Persyaratan
Android Studio + JDK 17 untuk build lokal. Project tidak membutuhkan koneksi internet saat dimainkan.
